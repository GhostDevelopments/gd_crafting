Config = {}
Config.Debug = false
Config.TextUIDistance = 2.0 -- Distance to show [E] crafting prompt
Config.CraftDistance = 3.5
-- Default blip settings. Set enabled = false to hide blips by default.
-- Each station can override these values using its own blip table.
Config.Blip = {
    enabled = false,
    sprite = 566,
    color = 48,
    scale = 0.75,
    display = 4,
    shortRange = true,
    label = 'Crafting Station'
}


Config.Stations = {
    {
        label = 'Female Crafting',
        coords = vec3(1128.4, -472.23, 66.68),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 90.0,
        duration = 5000, -- Station crafting time in milliseconds; remove to use recipe duration.
        blip = {
            enabled = true,
            sprite = 566,
            color = 48,
            scale = 0.75,
            display = 4,
            shortRange = true,
            label = 'Pocket Crafting'
        },
        recipes = {
            'pinkwallet',
            'handbag',
            'lipstick',
            'lipgloss',
            'eyelashes',
            'nailpolish',
            'acrylicnails',
            'foundation',
            'eyeshadow',
            'blush',
            'perfume',
            'pinkwatch',
            'designerpurse',
            'sunglasses',
            'highheels',
            'silkscarf',
            'diamondring',
            'goldbracelet',
            'diamondnecklace',
            'goldhoops',
            'anklet',
            'charmbracelet',
            'hairbrush',
            'hairbundles',
            'lacefrontwig',
            'flatiron',
            'bodylotion',
            'faceserum'
        }
    },
    {
        label = 'Female Crafting',
        coords = vec3(1135.48, -473.74, 66.7),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 90.0,
        duration = 15000, -- Station-specific time in milliseconds.
        blip = {
            enabled = false,
            label = 'Female Crafting'
        },
        recipes = {
            'pinkwallet',
            'handbag',
            'lipstick',
            'lipgloss',
            'eyelashes',
            'nailpolish',
            'acrylicnails',
            'foundation',
            'eyeshadow',
            'blush',
            'perfume',
            'pinkwatch',
            'designerpurse',
            'sunglasses',
            'highheels',
            'silkscarf',
            'diamondring',
            'goldbracelet',
            'diamondnecklace',
            'goldhoops',
            'anklet',
            'charmbracelet',
            'hairbrush',
            'hairbundles',
            'lacefrontwig',
            'flatiron',
            'bodylotion',
            'faceserum'
        }
    },

    -- Motel Rooms --
    {
        label = 'Drug Crafting',
        coords = vec3(309.22, -223.03, 53.65),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 90.0,
        duration = 65000, -- Station-specific time in milliseconds.
        blip = {
            enabled = false,
            label = 'Drug Crafting'
        },
        recipes = {
            'meth_bag',
            'brick_meth',
            'cokebaggy',
            'meth_raw',
            'baggy_weed',
            'weed_brick',
        }
    },
}

Config.Recipes = {

    -- ORIGINAL FEMALE ITEMS

    pinkwallet = {
        label = 'Pink Wallet',
        output = 'pinkwallet',
        amount = 5,
        duration = 5000,
        ingredients = {
            pelt = 2,
            pink_paint = 1,
            makeupkit = 1
        }
    },

    handbag = {
        label = 'Handbag',
        output = 'handbag',
        amount = 5,
        duration = 7000,
        ingredients = {
            pelt = 4,
            pink_paint = 2,
            makeupkit = 1
        }
    },

    lipstick = {
        label = 'Lipstick',
        output = 'lipstick',
        amount = 5,
        duration = 4000,
        ingredients = {
            pink_paint = 1,
            makeupkit = 1
        }
    },

    -- BEAUTY ITEMS

    lipgloss = {
        label = 'Lip Gloss',
        output = 'lipgloss',
        amount = 5,
        duration = 4000,
        ingredients = {
            pink_paint = 1,
            perfumeoil = 1,
            makeupkit = 1
        }
    },

    eyelashes = {
        label = 'Eyelashes',
        output = 'eyelashes',
        amount = 5,
        duration = 4500,
        ingredients = {
            fabric = 2,
            makeupkit = 1
        }
    },

    nailpolish = {
        label = 'Nail Polish',
        output = 'nailpolish',
        amount = 5,
        duration = 4000,
        ingredients = {
            pink_paint = 2,
            perfumeoil = 1
        }
    },

    acrylicnails = {
        label = 'Acrylic Nails',
        output = 'acrylicnails',
        amount = 5,
        duration = 5500,
        ingredients = {
            pink_paint = 2,
            jewelryparts = 1,
            makeupkit = 1
        }
    },

    foundation = {
        label = 'Foundation',
        output = 'foundation',
        amount = 5,
        duration = 5000,
        ingredients = {
            makeupkit = 2,
            perfumeoil = 1
        }
    },

    eyeshadow = {
        label = 'Eyeshadow Palette',
        output = 'eyeshadow',
        amount = 5,
        duration = 5000,
        ingredients = {
            pink_paint = 2,
            makeupkit = 1
        }
    },

    blush = {
        label = 'Blush Palette',
        output = 'blush',
        amount = 5,
        duration = 4500,
        ingredients = {
            pink_paint = 1,
            makeupkit = 2
        }
    },

    perfume = {
        label = 'Luxury Perfume',
        output = 'perfume',
        amount = 5,
        duration = 6000,
        ingredients = {
            perfumeoil = 3,
            makeupkit = 1
        }
    },

    -- FASHION ITEMS

    pinkwatch = {
        label = 'Pink Watch',
        output = 'pinkwatch',
        amount = 5,
        duration = 7000,
        ingredients = {
            jewelryparts = 3,
            pink_paint = 2,
            pelt = 1
        }
    },

    designerpurse = {
        label = 'Designer Purse',
        output = 'designerpurse',
        amount = 5,
        duration = 7500,
        ingredients = {
            pelt = 4,
            fabric = 3,
            pink_paint = 2
        }
    },

    sunglasses = {
        label = 'Designer Sunglasses',
        output = 'sunglasses',
        amount = 5,
        duration = 5000,
        ingredients = {
            jewelryparts = 2,
            pink_paint = 1
        }
    },

    highheels = {
        label = 'High Heels',
        output = 'highheels',
        amount = 5,
        duration = 8000,
        ingredients = {
            pelt = 4,
            fabric = 3,
            pink_paint = 2
        }
    },

    silkscarf = {
        label = 'Silk Scarf',
        output = 'silkscarf',
        amount = 5,
        duration = 5000,
        ingredients = {
            fabric = 4,
            pink_paint = 1
        }
    },

    -- JEWELRY ITEMS

    diamondring = {
        label = 'Diamond Ring',
        output = 'diamondring',
        amount = 5,
        duration = 8000,
        ingredients = {
            jewelryparts = 5,
            pink_paint = 1
        }
    },

    goldbracelet = {
        label = 'Gold Bracelet',
        output = 'goldbracelet',
        amount = 5,
        duration = 7000,
        ingredients = {
            jewelryparts = 4
        }
    },

    diamondnecklace = {
        label = 'Diamond Necklace',
        output = 'diamondnecklace',
        amount = 5,
        duration = 9000,
        ingredients = {
            jewelryparts = 6,
            pink_paint = 1
        }
    },

    goldhoops = {
        label = 'Gold Hoop Earrings',
        output = 'goldhoops',
        amount = 5,
        duration = 6000,
        ingredients = {
            jewelryparts = 3
        }
    },

    anklet = {
        label = 'Gold Anklet',
        output = 'anklet',
        amount = 5,
        duration = 5500,
        ingredients = {
            jewelryparts = 3,
            fabric = 1
        }
    },

    charmbracelet = {
        label = 'Charm Bracelet',
        output = 'charmbracelet',
        amount = 5,
        duration = 6500,
        ingredients = {
            jewelryparts = 4,
            pink_paint = 1
        }
    },

    -- HAIR ITEMS

    hairbrush = {
        label = 'Hair Brush',
        output = 'hairbrush',
        amount = 5,
        duration = 4000,
        ingredients = {
            jewelryparts = 1,
            fabric = 2
        }
    },

    hairbundles = {
        label = 'Hair Bundles',
        output = 'hairbundles',
        amount = 5,
        duration = 6500,
        ingredients = {
            fabric = 4,
            perfumeoil = 1
        }
    },

    lacefrontwig = {
        label = 'Lace Front Wig',
        output = 'lacefrontwig',
        amount = 5,
        duration = 8500,
        ingredients = {
            hairbundles = 2,
            fabric = 3,
            pink_paint = 1
        }
    },

    flatiron = {
        label = 'Hair Flat Iron',
        output = 'flatiron',
        amount = 5,
        duration = 7000,
        ingredients = {
            jewelryparts = 4,
            pelt = 1
        }
    },

    -- SELF CARE ITEMS

    bodylotion = {
        label = 'Body Lotion',
        output = 'bodylotion',
        amount = 5,
        duration = 4500,
        ingredients = {
            perfumeoil = 2,
            makeupkit = 1
        }
    },

    faceserum = {
        label = 'Face Serum',
        output = 'faceserum',
        amount = 5,
        duration = 5500,
        ingredients = {
            perfumeoil = 3,
            makeupkit = 1
        }
    },

    baggy_weed = {
        label = 'Weed Bag',
        output = 'baggy_weed',
        amount = 1000,
        duration = 5500,
        ingredients = {
            empty_weed_bag = 1000,
            weed_brick = 1
        }
    },

    weed_brick = {
        label = 'Brick Weed',
        output = 'weed_brick',
        amount = 1,
        duration = 5500,
        ingredients = {
            weed_leaf = 150,
            plastic_wrap = 2
        }
    },

        heroin_baggy = {
        label = 'Heroin Baggy',
        output = 'heroin_baggy',
        amount = 1,
        duration = 10000,
        ingredients = {
            brick_opium = 1,
            empty_weed_bag = 1000
        }
    },

    brick_opium = {
        label = 'Opium Brick',
        output = 'brick_opium',
        amount = 1,
        duration = 15000,
        ingredients = {
            opium_dry = 100,
            plastic_wrap = 2,
            highqualityscales = 1
        }
    },

    brick_meth = {
        label = 'Meth Brick',
        output = 'brick_meth',
        amount = 1,
        duration = 15000,
        ingredients = {
            meth_raw = 100,
            plastic_wrap = 2,
            highqualityscales = 1
        }
    },

    meth_raw = {
        label = 'Raw Meth',
        output = 'meth_raw',
        amount = 100,
        duration = 10000,
        ingredients = {
            ammonium_nitrate = 4,
            liquid_sulfur = 3,
            muriatic_acid = 5
        }
    },

    meth_bag = {
        label = 'Meth Bag',
        output = 'meth_bag',
        amount = 1000,
        duration = 10000,
        ingredients = {
            brick_meth = 1,
            empty_weed_bag = 1000
        }
    },
    
    coke_brick = {
        label = 'Cocaine Brick',
        output = 'coke_brick',
        amount = 1,
        duration = 15000,
        ingredients = {
            cocaineleaf = 100,
            plastic_wrap = 2,
            highqualityscales = 1
        }
    },

    cocaine = {
        label = 'Cocaine',
        output = 'cocaine',
        amount = 1000,
        duration = 10000,
        ingredients = {
            coke_brick = 1
        }
    },

    cokebaggy = {
        label = 'Cocaine Baggy',
        output = 'cokebaggy',
        amount = 1000,
        duration = 15000,
        ingredients = {
            cocaine = 1000,
            empty_weed_bag = 1000
        }
    }
}

