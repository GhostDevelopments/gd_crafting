local busy = false
local function notify(message, kind)
    lib.notify({ title = 'Crafting', description = message, type = kind or 'inform' })
end
local function craft(stationId, recipeId)
    if busy then return end
    local recipe = Config.Recipes[recipeId]
    if not recipe then return end
    busy = true
    local allowed = lib.callback.await('ghost_crafting:begin', false, stationId, recipeId)
    if not allowed then busy = false return notify('Missing ingredients, inventory space, or too far away.', 'error') end
    local done = lib.progressCircle({ duration = allowed, label = 'Crafting ' .. recipe.label,
        position = 'bottom', canCancel = true, disable = { move = true, car = true, combat = true },
        anim = { dict = 'mini@repair', clip = 'fixing_a_ped' } })
    TriggerServerEvent('ghost_crafting:finish', stationId, recipeId, done == true)
    busy = false
    notify(done and 'Crafting completed.' or 'Crafting cancelled.', done and 'success' or 'error')
end
-- Prefer the item label registered in ox_inventory over its internal spawn name.
local function itemLabel(itemName)
    local ok, item = pcall(function()
        return exports.ox_inventory:Items(itemName)
    end)
    if ok and type(item) == 'table' and type(item.label) == 'string' and item.label ~= '' then
        return item.label
    end
    return (Config.ItemLabels and Config.ItemLabels[itemName]) or itemName
end

local function openMenu(stationId)
    if busy then return end
    local station = Config.Stations[stationId]
    if not station then return end

    local options = {}
    for _, id in ipairs(station.recipes) do
        local recipe = Config.Recipes[id]
        if recipe then
            local ingredients = {}
            for item, count in pairs(recipe.ingredients) do
                ingredients[#ingredients + 1] = ('%s x%d'):format(itemLabel(item), count)
            end
            table.sort(ingredients)
            local recipeId = id
            options[#options + 1] = {
                title = ('%s x%d'):format(recipe.label, recipe.amount),
                description = ('Required: %s | Time: %.1fs'):format(table.concat(ingredients, ', '), (type(station.duration) == 'number' and station.duration or recipe.duration) / 1000),
                icon = 'box-open',
                onSelect = function()
                    craft(stationId, recipeId)
                end
            }
        end
    end
    if #options == 0 then return notify('No recipes configured.', 'error') end
    local contextId = 'ghost_crafting_station_' .. stationId
    lib.registerContext({ id = contextId, title = station.label, options = options })
    lib.showContext(contextId)
end
local createdBlips = {}
local textUiVisible = false
local activeStation = nil

local function hideStationText()
    if textUiVisible then
        lib.hideTextUI()
        textUiVisible = false
    end
    activeStation = nil
end


local function createStationBlip(station)
    local defaults = Config.Blip or {}
    local overrides = station.blip
    if overrides == false then return end
    if type(overrides) ~= 'table' then overrides = {} end

    local enabled = overrides.enabled
    if enabled == nil then enabled = defaults.enabled end
    if not enabled then return end

    local function setting(key, fallback)
        if overrides[key] ~= nil then return overrides[key] end
        if defaults[key] ~= nil then return defaults[key] end
        return fallback
    end

    local blip = AddBlipForCoord(station.coords.x, station.coords.y, station.coords.z)
    SetBlipSprite(blip, setting('sprite', 566))
    SetBlipColour(blip, setting('color', 48))
    SetBlipScale(blip, setting('scale', 0.75))
    SetBlipDisplay(blip, setting('display', 4))
    SetBlipAsShortRange(blip, setting('shortRange', true))
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(setting('label', station.label or 'Crafting Station'))
    EndTextCommandSetBlipName(blip)
    createdBlips[#createdBlips + 1] = blip
end

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    hideStationText()
    for _, blip in ipairs(createdBlips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end
end)

CreateThread(function()
    for _, station in ipairs(Config.Stations) do
        createStationBlip(station)
    end

    while true do
        local wait = 1000
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local nearestId, nearestDistance
        local interactionDistance = Config.TextUIDistance or Config.TargetDistance or 2.0

        for index, station in ipairs(Config.Stations) do
            local distance = #(coords - station.coords)
            if distance < 12.0 then wait = 200 end
            if distance <= interactionDistance and (not nearestDistance or distance < nearestDistance) then
                nearestId, nearestDistance = index, distance
            end
        end

        -- Do not draw the prompt over crafting menus or while crafting.
        local canInteract = nearestId and not busy and not IsPedInAnyVehicle(ped, false)
            and not IsEntityDead(ped) and not IsNuiFocused()

        if canInteract then
            wait = 0
            if activeStation ~= nearestId or not textUiVisible then
                hideStationText()
                activeStation = nearestId
                lib.showTextUI(('[E] Craft - %s'):format(Config.Stations[nearestId].label), {
                    position = 'left-center',
                    icon = 'box-open'
                })
                textUiVisible = true
            end
            if IsControlJustReleased(0, 38) then
                hideStationText()
                openMenu(nearestId)
            end
        else
            hideStationText()
        end
        Wait(wait)
    end
end)
