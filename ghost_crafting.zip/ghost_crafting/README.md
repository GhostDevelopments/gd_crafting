# ghost_crafting — Qbox + ox_lib TextUI + ox_inventory + your ox_lib

This package contains the exact `ox_lib` resource supplied by you and the updated `ghost_crafting` resource.

## Installation
1. Place both `ox_lib` and `ghost_crafting` folders in your resources directory.
2. Ensure dependencies start in order:

```cfg
ensure ox_lib
ensure ox_inventory
-- ox_target is no longer required
ensure ox_lib
ensure ghost_crafting
```

3. Customize box zones and recipes in `ghost_crafting/config.lua`.
4. Make sure recipe items exist in `ox_inventory/data/items.lua`.

## Integration
`ghost_crafting` uses `exports['ox_lib']:GetMenu().UI.Menu.Open` and `Close` directly. It does not use the old embedded NUI menu. The provided `ox_lib` is an independent resource with its original styling and files intact.

## Targeting
Walk within Config.TextUIDistance of a station and press E to open its crafting menu. No ox_target zones are created.

## Security / crafting notes
The server validates station proximity, recipe, ingredients, inventory capacity and duration. Materials are reserved when crafting begins and refunded on cancellation where possible. If the player disconnects or the resource restarts mid-craft, the reservation is lost. Ensure players have room for refunded items.


## Optional map blips

Set `Config.Blip.enabled = true` to enable blips by default for all stations, or keep it `false` and enable individual stations using `blip = { enabled = true }`.

Each station can set `blip = false` or `blip = { enabled = false }` to hide its blip. Station blip tables can override `sprite`, `color`, `scale`, `display`, `shortRange`, and `label`. Any omitted setting inherits `Config.Blip`.

The sample station has its blip enabled. Blips are client-side and are removed when the resource stops. No benches or NPCs are spawned.

## Per-station crafting duration
Set `duration = 5000` inside any entry of `Config.Stations` to override all recipe times at that station (milliseconds; minimum 1000, maximum 3600000). Different stations may use different durations even with identical recipes. Remove the station `duration` field to use the existing `Config.Recipes[recipeId].duration` for each item. The client progress circle and server-side completion validation both use the station-specific value.

## Item labels and neutral icons
Crafting menu ingredient names now use the registered ox_inventory item label via `exports.ox_inventory:Items(itemName)`, falling back to the item spawn name if no label is available. Ensure your items have `label` values in ox_inventory/data/items.lua. Recipe titles continue to use `Config.Recipes[id].label`. The menu and TextUI icons use a neutral open-box icon instead of a hammer.
