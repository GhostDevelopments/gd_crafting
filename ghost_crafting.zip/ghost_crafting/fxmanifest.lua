fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'ghost_crafting'
description 'Qbox crafting with ox_lib TextUI, ox_inventory and ox_lib context menus'
version '1.0.0'

shared_scripts { '@ox_lib/init.lua', 'config.lua' }
client_scripts { 'client.lua' }
server_scripts { 'server.lua' }
dependencies { 'ox_lib', 'ox_inventory' }
