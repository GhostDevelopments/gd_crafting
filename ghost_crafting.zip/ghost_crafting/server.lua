local active = {}
local function nearStation(source, stationId)
    local station = Config.Stations[stationId]
    if not station then return false end
    local ped = GetPlayerPed(source)
    if ped == 0 then return false end
    return #(GetEntityCoords(ped) - station.coords) <= (Config.CraftDistance + math.max(station.size.x, station.size.y) * 0.5)
end
local function validRecipe(stationId, recipeId)
    local station, recipe = Config.Stations[stationId], Config.Recipes[recipeId]
    if not station or not recipe then return nil end
    for _, id in ipairs(station.recipes) do
        if id == recipeId then return recipe end
    end
end
lib.callback.register('ghost_crafting:begin', function(source, stationId, recipeId)
    if active[source] or not nearStation(source, stationId) then return false end
    local recipe = validRecipe(stationId, recipeId)
    local station = Config.Stations[stationId]
    local duration = station.duration or (recipe and recipe.duration)
    if not recipe or type(duration) ~= 'number' or duration < 1000 or duration > 3600000 then return false end
    if not exports.ox_inventory:Items(recipe.output) then return false end
    for item, count in pairs(recipe.ingredients) do
        if not exports.ox_inventory:Items(item) or exports.ox_inventory:Search(source, 'count', item) < count then return false end
    end
    if not exports.ox_inventory:CanCarryItem(source, recipe.output, recipe.amount) then return false end
    -- Reserve ingredients before progress starts; refund on cancellation.
    local removed = {}
    for item, count in pairs(recipe.ingredients) do
        if not exports.ox_inventory:RemoveItem(source, item, count) then
            for refundItem, refundCount in pairs(removed) do exports.ox_inventory:AddItem(source, refundItem, refundCount) end
            return false
        end
        removed[item] = count
    end
    active[source] = { stationId = stationId, recipeId = recipeId, start = GetGameTimer(), ingredients = removed, duration = duration }
    return duration
end)
RegisterNetEvent('ghost_crafting:finish', function(stationId, recipeId, completed)
    local src = source
    local state = active[src]
    if not state or state.stationId ~= stationId or state.recipeId ~= recipeId then return end
    active[src] = nil
    local recipe = validRecipe(stationId, recipeId)
    if not recipe then return end
    local elapsed = GetGameTimer() - state.start
    if completed and elapsed >= state.duration - 250 and nearStation(src, stationId) and exports.ox_inventory:CanCarryItem(src, recipe.output, recipe.amount) then
        if exports.ox_inventory:AddItem(src, recipe.output, recipe.amount) then return end
    end
    for item, count in pairs(state.ingredients) do
        if not exports.ox_inventory:AddItem(src, item, count) then
            print(('[ghost_crafting] WARNING: Failed refund %s x%s to player %s'):format(item, count, src))
        end
    end
end)
AddEventHandler('playerDropped', function() active[source] = nil end)
